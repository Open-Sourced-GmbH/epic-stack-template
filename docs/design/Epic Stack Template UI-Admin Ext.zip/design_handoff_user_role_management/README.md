# Handoff: User & Role Management (Access)

Five admin surfaces + one auth state for dynamic RBAC, built as **template Design
Components** on the published **Epic Stack UI** (`EpicUI`) design system.

---

## Overview

This package covers the "Access" feature group derived from the *User & Rollen
Management* PRD (34 user stories): managing accounts, role assignments,
fine-grained permissions, and an audit trail. It adds a new **Access** sidebar
group (Users / Roles / Audit log) to the admin AppShell.

Surfaces:

| # | Surface | Route | Base reference template |
|---|---|---|---|
| 1 | Users list | `/admin/users` | `screen-admin-blog` (admin list) |
| 2 | User detail | `/admin/users/$id` | `screen-settings` (stacked cards) |
| 3 | Roles list | `/admin/roles` | `screen-admin-blog` (admin list) |
| 4 | Role editor | `/admin/roles/$id`, `/admin/roles/new` | `screen-settings` (stacked cards) |
| 5 | Audit log | `/admin/audit` | `screen-admin-blog` (admin list) |
| 6 | Deactivated-account sign-in | `/login` (deactivated state, story 33) | `screen-auth` (centered FormCard) |

Cross-cutting (not yet designed — see **Open / not-yet-built**): a 403 page for
non-managers, full responsive (table → stacked) and dark mode passes.

## About the design files

The `.dc.html` files in this bundle are **design references** — they are
**Design Components** authored against this repo's published `EpicUI` library and
its `@theme` tokens. They are *not* production code to copy verbatim. The task is
to **implement these surfaces as real routes/components in the Epic Stack app**,
using the established patterns:

- Real `app/components/ui/*` components (the ones each surface maps to below).
- SSR-first loaders/actions; **route-based dialogs** (ADR-023); the overlay
  no-portal convention (Dialog/Tooltip/Sheet render in place).
- Forms via **Conform + Zod**; auto-submit toggles via `requestSubmit`.
- **Tokens only** — every value maps to an existing `@theme` token; no hardcoded
  colors/fonts/radii (code-conventions).

Where a piece is genuinely net-new (the permission grant matrix, the role chips,
the status pill, the System/Custom marker), it is flagged below. Those should be
reconciled with the styleguide via `/to-grounded-design` before they become real
`ui/*` components.

## Fidelity

**High-fidelity.** Final colors, type, spacing, and interaction intent are
specified. Recreate pixel-accurately with the existing `EpicUI` components and
tokens. The few bespoke compositions (matrix, chips, status pill) include exact
token-based recipes below.

## Architecture references

- **ADR-068** — AppShell (full) + section sidebars. All five Access surfaces ride
  the AppShell; the new Access group renders only for users with management
  permissions (permission-gated chrome).
- **ADR-069** — dynamic RBAC (roles → permissions; `action:entity:scope`).
- **ADR-070** — audit log.
- **ADR-023** — route-based dialogs (destructive confirms).
- **EPT-64** — `Switch` via Conform `useInputControl`.
- Header seam: each surface feeds the shell's single `PageHeader` via
  `handle.adminHeader`.
- Glossary: `docs/agents/domain.md`. Styleguide grounding: `docs/agents/styleguide.md`.

---

## Permission model (RBAC)

Grants are strings of the form **`action:entity:scope`**.

- **Actions:** `create`, `read`, `update`, `delete`
- **Entities:** `user`, `role`, `note`, `audit` (extend per `domain.md`)
- **Scope:** `own` (records the user owns) or `any` (all records)

Examples: `update:note:any`, `read:user:own`, `delete:role:any`.

A **role** is a named set of grants. Roles are **System** (protected: no
rename/delete, identity locked) or **Custom** (fully editable). A user has many
roles; effective permissions are the union of their roles' grants.

**Admin floor (invariant):** at least one *active* user must always hold the
grant that manages access (`update:role:any` / `manage roles`). Operations that
would breach this are **blocked**:

- Deactivating/deleting the **last capable admin**.
- A user performing a destructive **self-action** that removes their own last
  managing capability.
- Saving a **role** whose grant changes would drop the system below the floor.

Blocked operations surface as an **explanatory dialog** (chosen treatment — see
User detail) telling the operator *why* and *what to do instead*.

---

## Global frame (every Access surface)

Built once; reused on surfaces 1–5. (Surface 6 uses the minimal auth navbar.)

### Navbar (AppShell full)
- Height **60px**, padding `0 24px`, `border-bottom: 1px solid var(--border)`,
  `flex: none`.
- Left: brand lockup — a **32px** rounded-`8px` `var(--brand)` square (▲ glyph,
  `var(--primary-foreground)`), wordmark "open / SOURCED" (14px 700 / 10px 600
  uppercase `letter-spacing:.2em` muted), then a muted back-link "Zurück zur
  Website" (14px).
- Right: theme customizer pill (rounded-`999px`, `1px var(--border)`, a 20px
  `var(--brand)` swatch + "Teal"), then identity cluster — a 32px brand-soft
  avatar (initials, `box-shadow:0 0 0 1px var(--border)`), name (13px 700),
  chevron.

### Section sidebar
- Width **208px**, `flex:none`, `border-right:1px solid var(--border)`,
  padding `20px 14px`, column `gap:18px`,
  `background: color-mix(in oklch, var(--background), var(--brand) 3%)`.
- Groups: each has an 11px 600 uppercase muted label (`letter-spacing:.08em`,
  padding `0 10px 4px`) over nav links.
- Nav link: `flex; gap:9px; padding:8px 10px; border-radius:var(--radius);
  font-size:13px`, 15px stroke icon. **Active** link: `background:var(--brand);
  color:var(--primary-foreground); font-weight:500`, `aria-current="page"`.
- Groups for Access surfaces: **Content** (Blog) · **Access** (Users, Roles,
  Audit log) · **System** (Cache). The Access group is the new addition.

### Content column
- `flex:1; padding:32px; display:flex; flex-direction:column; gap:20–24px`.
- **PageHeader**: eyebrow (11px 600 uppercase `var(--brand)`,
  `letter-spacing:.1em`) + title (**26px**, weight **650**,
  `letter-spacing:-0.02em`) + optional 13px muted subtitle; trailing action
  cluster (`Button`s) right-aligned (`align-items:flex-end; justify-content:
  space-between`).

### Shared FormCard
- `background:var(--card); border:1px solid var(--border);
  border-radius: calc(var(--radius) + 4px); overflow:hidden`.
- Card header: padding `18px 22px`, `border-bottom:1px solid var(--border)`,
  title 16px 600 + 13px muted description.
- Card body: padding `22px`, `display:grid; gap:16px`.
- **Destructive** variant: tint surface/border with `var(--destructive)` via
  `color-mix` (see User detail danger zone).

### Table card (lists)
- `background:var(--card); border:1px solid var(--border);
  border-radius:14px; overflow:hidden; box-shadow:0 1px 2px rgba(20,40,32,.06)`.
- Header row + body rows are CSS-grid rows sharing one `grid-template-columns`.
- Column header: 11px 600 uppercase muted, `letter-spacing:.05em`.
- Row: `padding:12px 16px; align-items:center; border-bottom:1px solid
  var(--border)` (last row none). Hover: `background: color-mix(in oklch,
  var(--card), var(--brand) 3%)`.
- **Selected** row: `background: color-mix(in oklch, var(--card), var(--brand)
  6%); box-shadow: inset 3px 0 0 var(--brand)` (brand left bar).
- Pager footer: `border-top:1px solid var(--border)`; left count text (13px
  muted), right pager (30px cells, active = `var(--brand)`/`#fff`).

---

## Surface 1 — Users list (`/admin/users`)

**Purpose:** find, filter, and act on accounts in bulk or per-row.

**Layout:** PageHeader ("Access / Users", subtitle, **Invite user** primary
action) → filter toolbar → Table card (max-width 980px).

**Filter toolbar** (`flex; gap:10px; flex-wrap:wrap`):
- Search `Input type="search"` with a leading 16px magnifier (absolute, `left:11px`)
  and `pl-9` on the input; `placeholder="Search by name or email…"`. Server-side
  search (Conform GET).
- Role `Select` (All roles / Admin / Editor / User) — 150px.
- Status `Select` (All status / Active / Deactivated) — 150px. Auto-submit on
  change via `requestSubmit`.

**Table** — columns `grid-template-columns: 30px 1fr 132px 110px 92px 32px;
gap:10px`:
1. **Select** checkbox (16px, rounded-5px; checked = `var(--brand)` + white ✓;
   header shows indeterminate dash).
2. **User** — `Avatar` (`size-9`, brand-soft fill for self/highlighted) + name
   (14px 600) over email (12px muted), both ellipsized.
3. **Roles** — role chips (see recipe).
4. **Status** — status pill (see recipe).
5. **Created** — 13px muted date.
6. **Row actions** — `Button variant="ghost" size="icon-sm"` (vertical ⋯)
   opening a `DropdownMenu`: View, Force log out, Deactivate, (sep) Delete
   (destructive).

**Bulk bar** (shown when ≥1 selected; replaces nothing, sits above the header
row): `background: color-mix(in oklch, var(--card), var(--brand) 7%)`; left =
checked box + "N selected"; right = `Button variant="outline" size="sm"` Force
log out / Deactivate, `variant="destructive" size="sm"` Delete, a 1px divider,
then `variant="ghost"` Clear.

**Deactivated row:** entire row `opacity:.6`; status pill = muted "Deactivated".

**States (build):** default, empty ("No users yet"), filtered-empty ("No users
match"), loading (`Skeleton` rows), error (`Alert tone="error"`).

### Role chip recipe (net-new — `EpicUI.Badge` was too flat here)
```css
.u-role{display:inline-flex;align-items:center;height:22px;padding:0 8px;
  border-radius:6px;font-size:11.5px;font-weight:600;letter-spacing:.02em;
  background:var(--muted);color:var(--muted-foreground);white-space:nowrap;}
/* privileged roles (admin, editor) elevate in brand tonal */
.u-role--elev{background:var(--brand-soft);color:var(--brand);
  box-shadow:inset 0 0 0 1px color-mix(in oklch,var(--brand) 22%,transparent);}
```
Rule: roles that grant management/elevated capability get `--elev`; ordinary
roles stay neutral so the eye lands on privilege.

### Status pill recipe (net-new)
```css
.u-status{display:inline-flex;align-items:center;gap:7px;height:24px;
  padding:0 11px 0 9px;border-radius:999px;font-size:12px;font-weight:600;
  letter-spacing:.01em;white-space:nowrap;}
.u-status .dot{width:6px;height:6px;border-radius:999px;flex:none;}
.u-status--active{background:color-mix(in oklch,var(--brand) 9%,var(--card));
  color:color-mix(in oklch,var(--brand),var(--foreground) 28%);
  box-shadow:inset 0 0 0 1px color-mix(in oklch,var(--brand) 16%,transparent);}
.u-status--active .dot{background:var(--brand);
  box-shadow:0 0 0 3px color-mix(in oklch,var(--brand) 20%,transparent);}
.u-status--off{background:var(--muted);color:var(--muted-foreground);
  box-shadow:inset 0 0 0 1px var(--border);}
.u-status--off .dot{background:var(--muted-foreground);opacity:.65;}
```

---

## Surface 2 — User detail (`/admin/users/$id`)

**Purpose:** manage one account's roles, status, sessions, and lifecycle.

**Decision — layout = single stacked column** (`max-width:760px`). (An
identity-rail two-column option was explored and dropped.)

**Decision — blocked-operation = explanatory dialog** (the inline-Alert option
was explored and dropped).

**Header:** back-link "All users" → name (26px 650) + status pill.

**Cards (stacked, `gap:20px`):**
1. **Identity** — 56px brand-soft `Avatar` + name (16px 650) / email (13px
   muted); hairline; meta rows (Joined, Last active, User ID in `--font-mono`).
2. **Roles** — assigned roles as removable chips (`.ud-chip`: brand-soft pill +
   an 18px round × button) + an "Assign a role" `Select` and an **Add role**
   `Button variant="outline"`. Revoke = remove grant; assign = add grant.
3. **Account status** — "This account is active" + `Button variant="outline"`
   **Deactivate** (↔ Reactivate when off). Deactivating ends sessions.
4. **Sessions & security** — "Active sessions" (N devices) + **Force log out**;
   "Password" + **Send reset email**. Rows split by hairlines.
5. **Danger** — destructive FormCard, **Delete user…** (`Button
   variant="destructive"`). Opens a route dialog (ADR-023) with `useDoubleCheck`.

**`.ud-chip` recipe:**
```css
.ud-chip{display:inline-flex;align-items:center;gap:6px;padding:3px 5px 3px 10px;
  border-radius:999px;font-size:13px;font-weight:550;background:var(--brand-soft);
  color:var(--brand);border:1px solid color-mix(in oklch,var(--brand) 22%,transparent);}
.ud-chip button{width:18px;height:18px;border-radius:999px;border:0;
  background:transparent;color:inherit;cursor:pointer;opacity:.7;}
.ud-chip button:hover{opacity:1;background:color-mix(in oklch,var(--brand) 18%,transparent);}
```

**Blocked-operation dialog** (last-capable-admin / self-action): a fixed,
centered overlay (`background: oklch(20% 0.02 172 / 0.45)`), card max-width
440px. Contents: a 40px round destructive-tinted ⚠ icon, title ("Can't
deactivate the last admin"), explanation, a bordered "What to do instead" note,
and actions (`Button variant="ghost"` Close + `Button` "Manage roles"). In the
app this is a **route-based dialog** (ADR-023), rendered in place.

**States (build):** default; blocked (dialog); destructive confirm (route dialog
+ double-check); reactivate (status off).

---

## Surface 3 — Roles list (`/admin/roles`)

**Purpose:** browse roles; create custom roles; never expose rename/delete on
System roles.

**Layout:** PageHeader ("Access / Roles", **New role** action) → Table card
(max-width 880px). Columns `grid-template-columns: 1fr 132px 96px 32px`.

1. **Role** — 36px rounded-10 icon tile (brand-soft for capable roles, muted for
   basic) + name (14px 600) over a 12px muted, ellipsized description.
2. **Type** — System vs Custom marker:
   - **System** = outline pill with a 12px lock icon: `1px var(--border)`,
     rounded-`999px`, 12px 500 muted, `var(--card)` fill.
   - **Custom** = `Badge variant="brand"`.
3. **Users** — right-aligned count (13px 600).
4. **Row actions** — `DropdownMenu`. **System roles expose no rename/delete** —
   only View/Duplicate; Custom roles get Edit / Duplicate / (sep) Delete.

Footer summary: "4 roles · 2 system, 2 custom".

**States (build):** default, empty, loading, error.

---

## Surface 4 — Role editor (`/admin/roles/$id` and `/new`)

**Purpose:** name a role and set its permission grants.

**Decision — permission matrix = dense grid** (a per-entity accordion variant was
explored and dropped).

**Layout** (`max-width:860px`): back-link "All roles" → name (26px) + Custom/System
badge → **Details** card → **Permissions** card → sticky **save bar**.

**Details card:** `Label`+`Input` Name, `Label`+`Textarea` Description (Conform +
Zod; `aria-invalid` repaints border via `--input-invalid`). For **System** roles
this card is **locked** (read-only/disabled).

**Permissions card:** header (16px 600 + description noting **own**/**any**) and a
right-aligned grant-count pill. Body = the grid.

### Permission grant matrix (net-new — likely a new composite, not a primitive)
A bordered grid (`1px var(--border)`, rounded-12):
- `grid-template-columns: minmax(104px,1.1fr) repeat(4,1fr)`.
- Header row: "Resource" (left) + Create / Read / Update / Delete (centered,
  11px 600 uppercase muted, bottom hairline).
- Each **entity** row: a 24px rounded-7 icon tile + entity name (13px 600), then
  four **cells**, each a centered pair of **scope toggle chips** (`own` / `any`).
- A cell may show a muted `—` where an action/scope is not applicable (e.g. Audit
  log has only Read).

**Scope chip (`.pc`)** — independently toggles a single grant:
```css
.pc{font-size:11px;font-weight:600;padding:3px 9px;border-radius:7px;
  border:1px solid var(--border);background:var(--background);
  color:var(--muted-foreground);cursor:pointer;line-height:1.4;}
.pc[data-on="1"]{background:var(--brand);border-color:var(--brand);
  color:var(--primary-foreground);}          /* granted */
.pc:hover{border-color:var(--brand);}
.pc[data-locked="1"]{cursor:not-allowed;opacity:.85;background:var(--brand-soft);
  border-color:color-mix(in oklch,var(--brand) 30%,transparent);
  color:var(--brand);}                        /* admin-floor protected */
```
Each chip = one grant string (`{action}:{entity}:{scope}`). On = granted.
`data-locked` cells are admin-floor-protected (can't be toggled off; show a lock
+ tooltip). System-role partial-lock uses the same locked treatment per cell.
In the prototype, a delegated `click` handler flips `data-on`/`aria-pressed`; in
the app this is controlled form state (Conform), submitted as the grant set.

**Save bar:** `position:sticky; bottom:20px`; left = brand status dot ("You have
unsaved changes"); right = `Button variant="ghost"` Discard + `StatusButton`
Save changes. Appears only when the form is dirty.

**States (build):** default (dirty/save bar), invalid (empty/dup name → `Field`
error), blocked (grant change breaches admin floor → blocked dialog or inline
`Alert tone="error"`), system partial-lock, create (empty form).

---

## Surface 5 — Audit log (`/admin/audit`)

**Purpose:** read-only, filterable record of every access change. Newest first.

**Layout:** PageHeader ("Access / Audit log") → filter toolbar (search +
event `Select` + **Export** `Button variant="outline"`) → Table card
(max-width 980px). Columns `grid-template-columns: 96px 1.25fr 140px 1.3fr 26px;
gap:10px`.

1. **When** — relative time (13px muted); absolute in a tooltip.
2. **Actor** — 28px `Avatar` + name. **Deleted actor fallback:** a dashed-border
   28px circle (struck user icon) + *italic muted* "Deleted user".
3. **Event** — tonal `Badge`: `role.grant` → `brand`; `role.update` →
   `secondary`; `user.deactivate` → `outline`; `user.delete` → `destructive`;
   `auth.login` → `secondary`.
4. **Target** — name + optional muted qualifier; `—` when none; *italic muted*
   "Deleted user" fallback.
5. **Expand** — chevron; expandable detail row.

**Expandable detail (chosen rendering — inline diff):** an expanded row tints
`color-mix(in oklch, var(--card), var(--brand) 3%)`, chevron rotates down, and a
bordered `--font-mono` block renders the grant diff:
- added line: `+`, `background: color-mix(in oklch, var(--brand) 12%, transparent)`,
  brand-leaning text — e.g. `+ grant   update:note:any`.
- removed line: `−`, `background: color-mix(in oklch, var(--destructive) 9%,
  transparent)`, destructive-leaning text — e.g. `− revoke delete:note:any`.

**States (build):** default, empty, loading, error.

---

## Surface 6 — Deactivated-account sign-in (`/login`, story 33)

**Purpose:** tell a user whose account was deactivated why they can't sign in.

**Layout:** minimal borderless auth navbar (logo + theme `Button
variant="ghost" size="icon-sm"`). Centered column with a top brand-glow radial
(`radial-gradient(60% 100% at 50% 0%, var(--brand-glow), transparent 70%)`), a
48px brand pine-logo tile, heading "This account is deactivated" (22px 650) +
muted subtitle, then a FormCard (max-width 380px) containing:
- `Alert tone="error"` → AlertTitle "Access suspended" + AlertDescription naming
  the email and reassuring data is safe.
- `Button size="wide"` **Contact an administrator** + `Button variant="ghost"
  size="wide"` **Back to sign in**.
- A muted "Reach out to support" footer link.

---

## Design tokens

Per-page accent block (set on the page root; everything else inherits from the DS
`@theme`):

```css
--brand:            oklch(60% 0.135 172);              /* teal — primary accent */
--brand-soft:       oklch(96% 0.025 172);              /* tonal fill */
--brand-glow:       oklch(from var(--brand) l c h / 0.32);
--primary:          var(--brand);
--primary-foreground: oklch(98.38% 0.0035 247.86);
--destructive:      oklch(57.7% 0.215 27.3);
--ring:             var(--brand);
```

Used from the DS `@theme` (do not hardcode — reference the tokens):
`--background` / `--foreground`, `--card` / `--card-foreground`,
`--muted` / `--muted-foreground`, `--border`, `--input`, `--radius`
(+ `--radius-sm/md/lg/xl`), `--font-sans`, `--font-mono`.

**Type scale (utilities):** `text-mega`, `text-h1…h6`, `text-body-2xl…2xs`,
`text-caption`, `text-button`. Headings carry their own weight/line-height.

**Radius:** inputs/buttons `rounded-md`; cards `calc(var(--radius) + 4px)`; table
cards 14px; pills `999px`.

**Layout constants:** navbar 60px · sidebar 208px · content padding 32px · card
header `18px 22px` · card body `22px` · row padding `12px 16px`.

**Status / event color logic** (tokens only): success/active/grant → brand;
neutral/secondary → muted/secondary; destructive/delete → `--destructive`.

## Interactions & behavior

- **Search / filters:** SSR loaders; filter `Select` change auto-submits via
  `requestSubmit`. Search debounced GET.
- **Selection → bulk bar:** row checkboxes drive a selection set; the bulk bar
  shows count + batch actions; header checkbox = select-all (indeterminate when
  partial).
- **Row menus:** `DropdownMenu` (no-portal). Destructive items open route dialogs.
- **Destructive confirms:** route-based dialog (ADR-023) + `useDoubleCheck`
  (button asks twice).
- **Toggles:** `Switch` (status/grant) via Conform `useInputControl`; permission
  chips are controlled grant state.
- **Audit rows:** expand/collapse details; keyboard-operable.
- **Animation:** focus ring is the shared cosy-focus halo (`box-shadow:0 0 0 2px
  oklch(from var(--brand) l c h / .2)`); buttons have an optional ripple; respect
  `prefers-reduced-motion`.

## State management

- Per surface: filter/search params (URL), selection set (Users list), dirty +
  grant set (Role editor), expanded row id (Audit), dialog open (route).
- Data: SSR loaders for lists/detail; actions for mutations (assign/revoke role,
  deactivate/reactivate, force-logout, password-reset, delete, save role).
- Guards: admin-floor invariant enforced server-side; blocked ops return the
  reason for the dialog.

## Accessibility (epic-ui-guidelines)

- `navigation` + `main` landmarks; `aria-current="page"` on the active nav link.
- Keyboard-navigable matrix, menus, and accordions; `role="switch"` toggles.
- Focusable tooltip trigger on **disabled** controls (focusable-span pattern).
- `Alert tone="error"` announces assertively; status alerts use `role="status"`.
- Tables degrade to stacked cards at small widths (responsive — to build).

## Open / not-yet-built

- **403 / non-manager** page; permission-gated hiding of the Access group.
- Full **responsive** (table → stacked) and **dark mode** passes (the shell flips
  on a `.dark` class; all tokens already flip).
- List **empty / filtered-empty / loading / error** states (happy-path built).
- Role editor **invalid / blocked / system partial-lock / create** states.
- Net-new pieces to formalize via `/to-grounded-design`: the **permission grant
  matrix** composite, **role chips** (`.u-role`), **status pill** (`.u-status`),
  and the **System/Custom marker**.

## Files in this bundle

| File | Surface |
|---|---|
| `AdminUsers.dc.html` | Users list |
| `AdminUserDetail.dc.html` | User detail |
| `AdminRoles.dc.html` | Roles list |
| `AdminRoleEditor.dc.html` | Role editor |
| `AdminAudit.dc.html` | Audit log |
| `AuthDeactivated.dc.html` | Deactivated sign-in |

These are Design Components (`<x-dc>` + `<x-import component-from-global-scope=
"EpicUI.*">`). Reference templates they extend live in the design system under
`templates/admin-blog`, `templates/settings-profile`, `templates/section-shell`,
`templates/auth-sign-in`. Component usage/props: `components/general/<Name>/
<Name>.prompt.md` + `<Name>.d.ts`. Tokens + conventions: `styles.css`,
`_ds_bundle.css`, and the repo's `app/styles/tailwind.css` `@theme`.
</content>
